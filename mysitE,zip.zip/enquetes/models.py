from django.db import models
from django.utils import timezone
import datetime

# Create your models here.
class Pergunta(models.Model):
    texto = models.CharField(max_length = 150)
    data_publi = models.DateTimeField('Data de Publicação')
    def __str__(self): #Usar sempre self
        return self.texto
    def ano_atual(self):
        return self.data_publi >= timezone.now() - datetime.timedelta(days=1)

class Alternativa(models.Model):
    texto = models.CharField(max_length = 80)
    qtd_votos = models.IntegerField('Quantidade de votos')
    pergunta = models.ForeignKey(Pergunta, on_delete= models.CASCADE)
    def __str__(self):
        return '{} ({})'.format(self.texto, self.pergunta)