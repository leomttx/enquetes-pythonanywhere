from . import views
from django.urls import path

urlpatterns = [
    path('', views.index, name ='index'),
    path('enquete/<int:perguntas_id/',views.detalhes, name = 'detalhes'),
    path('enquete/<int:perguntas_id/votacao',views.votacao, name = 'votacao'),
    #path('enquete/<int:perguntas_id/votacao/resultado/',views.resultado, name = 'resultado'),
    path('sobre/', views.sobre, name='sobre'),
]