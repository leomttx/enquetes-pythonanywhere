from django.shortcuts import render
from django.http import HttpResponse
# Create your views here.
def index(request):
    return HttpResponse('<h1>App <u> ENQUETES <u>! </h1>')

def detalhes(request, perguntas_id):
    resposta = '<h1>Detalhes da enquete %s<h1>' % perguntas_id
    return HttpResponse(resposta)

def votacao(request, perguntas_id):
    resposta = '<h1>Votações da enquete %s<h1>' % perguntas_id
    return HttpResponse(resposta)

def sobre(request):
    return HttpResponse('&copy; DSWEB/LEOMTTX/2023')